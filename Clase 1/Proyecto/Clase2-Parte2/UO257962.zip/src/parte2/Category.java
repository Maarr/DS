package parte2;

public class Category {
	
	private String name;

	public Category() {
		
		
	}
	
	
	double getPrice(Rental rental) {
			return 0;
	}
	
	int getPoints(Rental rental) {
		return 0;
	}	
	
	
}
